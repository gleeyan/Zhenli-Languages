package com.codingdojo.LanguageProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LanguageProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(LanguageProjectApplication.class, args);
	}

}
