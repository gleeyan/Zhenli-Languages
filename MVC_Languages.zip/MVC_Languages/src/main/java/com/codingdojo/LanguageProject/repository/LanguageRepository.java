package com.codingdojo.LanguageProject.repository;


import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.codingdojo.LanguageProject.models.Language;

@Repository
public interface LanguageRepository extends CrudRepository<Language, Long> {

    List<Language> findAll();
}

